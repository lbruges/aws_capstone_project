  const AWS = require('aws-sdk');
  const dynamoDb = new AWS.DynamoDB.DocumentClient();
  
  exports.handler = async (event) => {
      const { zone, date, pricePerM3 } = event;
  
      if (!zone || !date || !pricePerM3) {
          return {
              statusCode: 400,
              body: JSON.stringify({ message: 'Missing required parameters.' }),
          };
      }
  
      const params = {
          TableName: 'GasPrices',
          Item: {
              zone: zone,
              date: date,
              pricePerM3: pricePerM3,
          },
      };
  
      try {
          await dynamoDb.put(params).promise();
          return {
              statusCode: 200,
              body: JSON.stringify({ message: 'Item successfully inserted.' }),
          };
      } catch (error) {
          console.error('Error inserting item:', error);
          return {
              statusCode: 500,
              body: JSON.stringify({ message: 'Error inserting item.' }),
          };
      }
  };

