const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { zone, date } = event.queryStringParameters;

    // Validación: Comprobar si se proporcionaron los parámetros necesarios
    if (!zone || !date) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Missing required parameters: zone and date.' }),
        };
    }

    // Parámetros para la consulta en DynamoDB
    const params = {
        TableName: 'GasPrices',
        KeyConditionExpression: '#zone = :zone and #date = :date',
        ExpressionAttributeNames: {
            '#zone': 'zone',
            '#date': 'date',
        },
        ExpressionAttributeValues: {
            ':zone': zone,
            ':date': date,
        },
    };

    try {
        // Ejecutamos la consulta para buscar el ítem en DynamoDB
        const result = await dynamoDb.query(params).promise();

        // Si encontramos el ítem, lo devolvemos
        if (result.Items.length > 0) {
            return {
                statusCode: 200,
                body: JSON.stringify(result.Items[0]),  // Devolvemos el primer ítem encontrado
            };
        } else {
            // Si no encontramos el ítem
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Item not found for the provided zone and date.' }),
            };
        }
    } catch (error) {
        console.error('Error fetching item:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error fetching item.' }),
        };
    }
};
