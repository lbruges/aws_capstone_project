import boto3
import os
import json
from datetime import datetime, timedelta, timezone

# Inicializar el cliente SQS
sqs = boto3.client('sqs')

# Obtener la URL de la cola SQS desde una variable de entorno
queue_url = os.environ['SQS_QUEUE_URL']

def lambda_handler(event, context):
    """
    Función Lambda para enviar eventos recibidos a una cola SQS.
    """
    try:
        utc_menos_5 = timezone(timedelta(hours=-5))
        
        # Obtener la fecha y hora actual en UTC-5
        fecha_utc_menos_5 = datetime.now(utc_menos_5)
        data = event["SQSEvent"].split(",")
        # Formatear la fecha en formato ISO 8601
        today = fecha_utc_menos_5.strftime("%m-%Y")
        # Procesar cada registro del evento recibido
        for record in data:
            # Crear el cuerpo del mensaje basado en el evento recibido

            # Convertir el cuerpo del mensaje a formato JSON
            body_json = {"zone": record,
                        "date": today}
            message_body_json = json.dumps(body_json)

            # Enviar el mensaje a SQS
            response = sqs.send_message(
                QueueUrl=queue_url,
                MessageBody=message_body_json,
                # (Opcional) Atributos adicionales para filtrar mensajes
                MessageAttributes={
                    'EventType': {
                        'StringValue': 'CustomEvent',  # Cambia según tu necesidad
                        'DataType': 'String'
                    }
                }
            )

            print(f"Mensaje enviado con éxito a SQS. ID del mensaje: {response['MessageId']}")

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Eventos enviados a SQS con éxito"})
        }

    except Exception as e:
        print(f"Error enviando mensajes a SQS: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }